import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter, Navigate, NavLink, Outlet, Route, Routes, useNavigate } from 'react-router-dom';
import { AuthProvider, RequireAuth, RequirePermission, ROLE_LABELS, useAuth } from './auth';
import { ThemeProvider, useTheme } from './lms/theme';

// Route-level code splitting keeps the login and each role cabinet small. In
// particular, SCADA, ECharts and authoring code no longer block the field
// operator screen before its 3D iframe can start loading.
const LoginPage = React.lazy(() => import('./pages/LoginPage'));
const OperatorHomePage = React.lazy(() => import('./pages/operator/HomePage'));
const CoursesPage = React.lazy(() => import('./pages/operator/CoursesPage'));
const PracticePage = React.lazy(() => import('./pages/operator/PracticePage'));
const ExamsPage = React.lazy(() => import('./pages/operator/ExamsPage'));
const CompetenciesPage = React.lazy(() => import('./pages/operator/CompetenciesPage'));
const HistoryPage = React.lazy(() => import('./pages/operator/HistoryPage'));
const ProfilePage = React.lazy(() => import('./pages/operator/ProfilePage'));
const ModuleStudyPage = React.lazy(() => import('./pages/operator/ModuleStudyPage'));
const InstructorHomePage = React.lazy(() => import('./pages/instructor/HomePage'));
const InstructorGroupsPage = React.lazy(() => import('./pages/instructor/GroupsPage'));
const GroupDetailPage = React.lazy(() => import('./pages/instructor/GroupDetailPage'));
const InstructorCoursesPage = React.lazy(() => import('./pages/instructor/CoursesPage'));
const InstructorTasksPage = React.lazy(() => import('./pages/instructor/TasksPage'));
const MonitoringPage = React.lazy(() => import('./pages/instructor/MonitoringPage'));
const AnalyticsPage = React.lazy(() => import('./pages/instructor/AnalyticsPage'));
const SessionReviewsPage = React.lazy(() => import('./pages/instructor/SessionReviewsPage'));
const ModuleConstructorPage = React.lazy(() => import('./pages/instructor/ModuleConstructorPage'));
const AdminUsersPage = React.lazy(() => import('./pages/admin/UsersPage'));
const RolesPage = React.lazy(() => import('./pages/admin/RolesPage'));
const AdminGroupsPage = React.lazy(() => import('./pages/admin/GroupsPage'));
const AdminCoursesPage = React.lazy(() => import('./pages/admin/CoursesPage'));
const AdminTasksPage = React.lazy(() => import('./pages/admin/TasksPage'));
const AdminScenariosPage = React.lazy(() => import('./pages/admin/ScenariosPage'));
const SettingsPage = React.lazy(() => import('./pages/admin/SettingsPage'));
const LogsPage = React.lazy(() => import('./pages/admin/LogsPage'));
const FieldOperatorScreen = React.lazy(() => import('./pages/admin/FieldOperatorScreen'));
const PracticeRunner = React.lazy(() => import('./pages/PracticeRunner'));
const DebriefPage = React.lazy(() => import('./pages/DebriefPage'));
const HmiPage = React.lazy(() => import('./pages/HmiPage'));
const ChatWidget = React.lazy(() => import('./components/ChatWidget'));
const PracticeInvite = React.lazy(() => import('./components/PracticeInvite'));

import './index.css';

interface NavItem {
  to: string;
  label: string;
  ico: string;
}

const OPERATOR_NAV: NavItem[] = [
  { to: '/', label: 'Главная', ico: '⌂' },
  { to: '/courses', label: 'Мои курсы', ico: '▤' },
  { to: '/practice', label: 'Практика', ico: '▶' },
  { to: '/exams', label: 'Экзамены', ico: '✎' },
  { to: '/competencies', label: 'Мои компетенции', ico: '◍' },
  { to: '/history', label: 'История', ico: '☷' },
  { to: '/profile', label: 'Профиль', ico: '◉' },
];

const FIELD_OPERATOR_NAV: NavItem[] = [
  { to: '/', label: 'Главная', ico: '⌂' },
  { to: '/field', label: 'Экран полевого оператора', ico: '◱' },
  { to: '/courses', label: 'Мои курсы', ico: '▤' },
  { to: '/practice', label: 'Практика', ico: '▶' },
  { to: '/exams', label: 'Экзамены', ico: '✎' },
  { to: '/competencies', label: 'Мои компетенции', ico: '◍' },
  { to: '/history', label: 'История', ico: '☷' },
  { to: '/profile', label: 'Профиль', ico: '◉' },
];

const INSTRUCTOR_NAV: NavItem[] = [
  { to: '/instructor', label: 'Главная', ico: '⌂' },
  { to: '/instructor/groups', label: 'Группы', ico: '▦' },
  { to: '/instructor/courses', label: 'Курсы · конструктор', ico: '▤' },
  { to: '/instructor/tasks', label: 'Практические задания', ico: '▣' },
  { to: '/instructor/monitoring', label: 'Мониторинг', ico: '◉' },
  { to: '/instructor/session-reviews', label: 'Оценка сессий', ico: '✓' },
  { to: '/instructor/analytics', label: 'Аналитика', ico: '◔' },
];

const ADMIN_NAV: NavItem[] = [
  { to: '/admin/users', label: 'Пользователи', ico: '◈' },
  { to: '/admin/roles', label: 'Роли', ico: '◐' },
  { to: '/admin/groups', label: 'Группы', ico: '▦' },
  { to: '/admin/courses', label: 'Курсы', ico: '▤' },
  { to: '/admin/tasks', label: 'Задания', ico: '▣' },
  { to: '/admin/scenarios', label: 'Сценарии', ico: '▸' },
  { to: '/admin/operator-screen', label: 'Экран полевого оператора', ico: '◱' },
  { to: '/admin/settings', label: 'Настройки', ico: '☰' },
  { to: '/admin/logs', label: 'Журнал системы', ico: '☷' },
];

type Cabinet = 'admin' | 'instructor' | 'operator' | 'field';

function cabinetOf(permissions: string[]): Cabinet {
  if (permissions.includes('manage_users')) return 'admin';
  if (
    permissions.includes('manage_groups') ||
    permissions.includes('view_analytics') ||
    permissions.includes('monitor_operators')
  ) {
    return 'instructor';
  }
  if (permissions.includes('view_field_operator_screen')) return 'field';
  return 'operator';
}

const CABINET_TITLE: Record<Cabinet, string> = {
  admin: 'Кабинет администратора',
  instructor: 'Кабинет инструктора',
  operator: 'Кабинет консольного оператора',
  field: 'Кабинет полевого оператора',
};

function ThemeToggle() {
  const { theme, toggle } = useTheme();
  return (
    <button className="theme-toggle" onClick={toggle} title="Переключить тему">
      {theme === 'dark' ? '☀ Светлая' : '◐ Тёмная'}
    </button>
  );
}

function SidebarNav() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [confirmArm, setConfirmArm] = React.useState(false);
  const cabinet = cabinetOf(user?.permissions ?? []);
  const nav =
    cabinet === 'admin'
      ? ADMIN_NAV
      : cabinet === 'instructor'
        ? INSTRUCTOR_NAV
        : cabinet === 'field'
          ? FIELD_OPERATOR_NAV
          : OPERATOR_NAV;

  const items = [...nav];
  if (user?.permissions.includes('view_scheme') && !items.some((n) => n.to === '/hmi')) {
    items.push({ to: '/hmi', label: 'Тренажер · SCADA', ico: '◈' });
  }

  return (
    <>
      <div className="side-section">{CABINET_TITLE[cabinet]}</div>
      {items.map((n) => n.to === '/hmi' ? (
        <button key={n.to} type="button" className="side-link" onClick={() => setConfirmArm(true)}>
          <span className="side-ico">{n.ico}</span>
          <span>{n.label}</span>
        </button>
      ) : (
        <NavLink key={n.to} to={n.to} end={n.to === '/'} className={({ isActive }) => `side-link${isActive ? ' on' : ''}`}>
          <span className="side-ico">{n.ico}</span>
          <span>{n.label}</span>
        </NavLink>
      ))}
      {confirmArm && (
        <div className="modal-overlay" role="dialog" aria-modal="true" aria-label="Переход в АРМ">
          <div className="modal">
            <h2>Перейти в тренажёр SCADA?</h2>
            <p>Откроется режим АРМ оператора с вкладкой «Атмосферный блок».</p>
            <div className="fp-row">
              <button className="btn btn-start" onClick={() => { setConfirmArm(false); navigate('/hmi?arm=1'); }}>Перейти в АРМ</button>
              <button className="btn" onClick={() => setConfirmArm(false)}>Отмена</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

function Shell() {
  const { user, logout } = useAuth();
  const roleLabel = (user?.roles ?? []).map((r) => ROLE_LABELS[r] ?? r).join(', ');
  const fullName = user?.full_name || user?.username || '';
  const initials = (fullName || '?').slice(0, 1).toUpperCase();
  const cabinet = cabinetOf(user?.permissions ?? []);
  const showChat = cabinet === 'operator' || cabinet === 'field';

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="side-brand">
          <div className="logo">Э</div>
          <div>
            <div className="side-brand-title">ЭЛОУ-АВТ</div>
            <div className="side-brand-sub">Тренажерный комплекс</div>
          </div>
        </div>
        <nav className="side-nav">
          <SidebarNav />
        </nav>
        <div className="side-foot">
          <div className="side-user">
            <span className="avatar">{initials}</span>
            <div>
              <div className="side-user-name">{fullName}</div>
              <div className="side-user-role">{roleLabel}</div>
            </div>
          </div>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <div className="topbar-title">{CABINET_TITLE[cabinet]}</div>
          <div className="topbar-right">
            <ThemeToggle />
            <button className="btn" onClick={logout}>Выйти</button>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
        {showChat && <ChatWidget />}
        <PracticeInvite />
      </div>
    </div>
  );
}

function HomeRedirect() {
  const { user } = useAuth();
  const cabinet = cabinetOf(user?.permissions ?? []);
  if (cabinet === 'admin') return <Navigate to="/admin/users" replace />;
  if (cabinet === 'instructor') return <Navigate to="/instructor" replace />;
  return <Navigate to="/" replace />;
}

function RootPage() {
  const { user } = useAuth();
  const cabinet = cabinetOf(user?.permissions ?? []);
  if (cabinet === 'admin') return <Navigate to="/admin/users" replace />;
  if (cabinet === 'instructor') return <Navigate to="/instructor" replace />;
  return <OperatorHomePage />;
}

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <ThemeProvider>
      <BrowserRouter>
        <AuthProvider>
          <React.Suspense fallback={<div className="auth-loading">Загрузка интерфейса…</div>}>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route element={<RequireAuth><Shell /></RequireAuth>}>
              <Route path="/" element={<RootPage />} />
              <Route path="/courses" element={<RequirePermission permissions={['view_courses']}><CoursesPage /></RequirePermission>} />
              <Route path="/practice" element={<RequirePermission permissions={['view_courses']}><PracticePage /></RequirePermission>} />
              <Route path="/exams" element={<RequirePermission permissions={['view_courses']}><ExamsPage /></RequirePermission>} />
              <Route path="/competencies" element={<RequirePermission permissions={['view_competencies']}><CompetenciesPage /></RequirePermission>} />
              <Route path="/history" element={<RequirePermission permissions={['view_history']}><HistoryPage /></RequirePermission>} />
              <Route path="/profile" element={<RequirePermission permissions={['view_profile']}><ProfilePage /></RequirePermission>} />
              <Route path="/run/:taskId" element={<RequirePermission permissions={['view_courses']}><PracticeRunner /></RequirePermission>} />
              <Route path="/debrief/:sessionId" element={<RequirePermission permissions={['view_history']}><DebriefPage /></RequirePermission>} />
              <Route path="/study/:moduleId" element={<RequirePermission permissions={['view_courses']}><ModuleStudyPage /></RequirePermission>} />

              <Route path="/instructor" element={<RequirePermission permissions={['view_analytics', 'view_group_progress']}><InstructorHomePage /></RequirePermission>} />
              <Route path="/instructor/groups" element={<RequirePermission permissions={['view_group_progress']}><InstructorGroupsPage /></RequirePermission>} />
              <Route path="/instructor/groups/:groupId" element={<RequirePermission permissions={['view_group_progress']}><GroupDetailPage /></RequirePermission>} />
              <Route path="/instructor/tasks" element={<RequirePermission permissions={['view_group_progress', 'manage_practice_tasks']}><InstructorTasksPage /></RequirePermission>} />
              <Route path="/instructor/monitoring" element={<RequirePermission permissions={['monitor_operators']}><MonitoringPage /></RequirePermission>} />
              <Route path="/instructor/analytics" element={<RequirePermission permissions={['view_analytics']}><AnalyticsPage /></RequirePermission>} />
              <Route path="/instructor/session-reviews" element={<RequirePermission permissions={['view_analytics']}><SessionReviewsPage /></RequirePermission>} />
              <Route path="/instructor/modules/:moduleId" element={<RequirePermission permissions={['manage_courses']}><ModuleConstructorPage /></RequirePermission>} />
              <Route path="/instructor/courses" element={<RequirePermission permissions={['manage_courses', 'view_courses']}><InstructorCoursesPage /></RequirePermission>} />

              <Route path="/admin/users" element={<RequirePermission permissions={['manage_users']}><AdminUsersPage /></RequirePermission>} />
              <Route path="/admin/roles" element={<RequirePermission permissions={['manage_users']}><RolesPage /></RequirePermission>} />
              <Route path="/admin/groups" element={<RequirePermission permissions={['manage_users', 'manage_groups']}><AdminGroupsPage /></RequirePermission>} />
              <Route path="/admin/courses" element={<RequirePermission permissions={['manage_courses']}><AdminCoursesPage /></RequirePermission>} />
              <Route path="/admin/tasks" element={<RequirePermission permissions={['manage_practice_tasks']}><AdminTasksPage /></RequirePermission>} />
              <Route path="/admin/scenarios" element={<RequirePermission permissions={['manage_courses']}><AdminScenariosPage /></RequirePermission>} />
              <Route path="/admin/operator-screen" element={<RequirePermission permissions={['manage_users']}><FieldOperatorScreen /></RequirePermission>} />
              <Route path="/admin/settings" element={<RequirePermission permissions={['manage_settings']}><SettingsPage /></RequirePermission>} />
              <Route path="/admin/logs" element={<RequirePermission permissions={['view_logs']}><LogsPage /></RequirePermission>} />

              <Route path="/field" element={<RequirePermission permissions={['view_field_operator_screen']}><FieldOperatorScreen /></RequirePermission>} />

              <Route path="/hmi" element={<RequirePermission permissions={['view_scheme']}><HmiPage /></RequirePermission>} />
              <Route path="*" element={<HomeRedirect />} />
            </Route>
          </Routes>
          </React.Suspense>
        </AuthProvider>
      </BrowserRouter>
    </ThemeProvider>
  </React.StrictMode>,
);
